# Textos da ficha da loja (português do Brasil)

**Nome do app (até 30 caracteres):** DiaClaro: agenda e clima

**Descrição curta (até 80 caracteres):**
Agenda, tarefas, notícias e previsão do tempo em um só lugar.

**Descrição completa:**
O DiaClaro reúne o que você precisa para organizar o dia em um só app leve e bonito.

📅 AGENDA E FERIADOS
Eventos, consultas, lembretes e aniversários, com os feriados nacionais já no calendário e repetição diária, semanal, mensal ou anual.

✅ TAREFAS E NOTAS
Tarefas com prioridade, prazo e subtarefas. Notas com categorias e fixação.

🔔 LEMBRETES
Avisos no celular antes dos seus compromissos, com som e vibração, e exportação da agenda para o calendário do aparelho.

🌦️ PREVISÃO DO TEMPO
Clima do local exato onde você está, busca de qualquer cidade, radar com mapa, nascer e pôr do sol, UV, vento, umidade e mais. A tela do clima ganha a cor e a animação do tempo: chuva caindo, raios e tempestade.

⛈️ ALERTAS DE TEMPESTADE
Aviso quando a previsão indicar tempestade, granizo, vendaval ou chuva torrencial na sua região.

📰 NOTÍCIAS
Manchetes de jornais e agências do Brasil e do mundo: política, esporte, economia, tecnologia, ciência, cultura e a sua região. Atualizadas todo dia e salvas para ler sem internet.

💬 ENVIE PELO WHATSAPP
Mande a agenda, as tarefas, o clima ou uma notícia para qualquer número, com a mensagem pronta para enviar.

🔒 PRIVACIDADE
Sem conta e sem anúncios. Seus eventos, tarefas e notas ficam só no seu aparelho.

**Categoria:** Produtividade
**Tags sugeridas:** agenda, calendário, tarefas, clima, notícias
**E-mail de contato / site / política:** seus dados + URL de privacidade.html

---

# Respostas sugeridas nos formulários do Play Console
(Confira cada pergunta, pois os formulários mudam. Estas são as respostas coerentes com o app.)

**Anúncios:** o app não contém anúncios.
**Acesso ao app:** todas as funções estão disponíveis sem login.
**Público-alvo:** 13 anos ou mais (não direcionado a crianças).
**Classificação de conteúdo:** questionário sem violência, sexo ou jogos de azar. Notícias de terceiros podem exibir temas adultos nas manchetes; declare que o app apresenta conteúdo de terceiros (manchetes de jornais).
**App de notícias:** responda que apresenta notícias de terceiros e informe as fontes (G1, Folha, BBC, Agência Brasil, Google Notícias etc.).

**Segurança dos dados:**
- Coleta de dados pelo desenvolvedor: **nenhum dado é coletado ou enviado aos servidores do desenvolvedor** (tudo fica no aparelho).
- Localização aproximada/precisa: usada para o clima; enviada a serviços de terceiros (Open-Meteo e outros) para obter a previsão. Não é armazenada pelo desenvolvedor. Se o formulário exigir, declare como "compartilhada com terceiros, funcionalidade do app, opcional".
- Dados criptografados em trânsito: sim (https).
- O usuário pode pedir exclusão: sim, limpando os dados do app.

**Permissões (Android/TWA):** notificações (POST_NOTIFICATIONS) e localização, pedidas somente quando o usuário usa a função.
