# DiaClaro na Google Play — passo a passo

O DiaClaro é um PWA. Para a Play Store ele vira um app Android (formato TWA) gerado a partir do site hospedado. Eu não tenho acesso à sua conta do Google Play, então a publicação final é feita por você; abaixo está tudo pronto.

## 0. O que você precisa
- **Conta de desenvolvedor Google Play**: taxa única de US$ 25, com verificação de identidade (https://play.google.com/console/signup).
- **Hospedagem https com domínio próprio** para os arquivos do app (DiaClaro.html, sw.js, manifest.webmanifest, ícones, pasta play-store/ e privacidade.html). Exemplos gratuitos: GitHub Pages, Netlify, Cloudflare Pages. O app **precisa abrir em https** e o manifesto e o service worker precisam estar acessíveis na mesma pasta.
- **Contas pessoais novas** (criadas depois de 13/11/2023) precisam passar por **teste fechado com pelo menos 12 testadores por 14 dias seguidos** antes de liberar a produção. Confirme a regra atual no Play Console, pois ela muda.

## 1. Hospedar
1. Suba todos os arquivos desta entrega para o seu domínio (ex.: https://seudominio.com/diaclaro/).
2. Em `privacidade.html`, troque `[SEU NOME]` e `[SEU E-MAIL]` pelos seus dados. A Play exige uma URL pública de política de privacidade.
3. Abra no Chrome do celular, confira se carrega e se aparece "Instalar app".

## 2. Gerar o pacote (.aab)
Forma mais simples, sem instalar nada:
1. Acesse https://www.pwabuilder.com e cole a URL do app (ex.: https://seudominio.com/diaclaro/DiaClaro.html).
2. Confira a pontuação do PWA. O manifesto já tem id, ícones normais e maskable, categorias, atalhos e capturas de tela.
3. Clique em **Package for stores → Android → Google Play**.
4. Campos: ID do pacote (ex.: `br.com.seunome.diaclaro`, não pode mudar depois), nome "DiaClaro", versão 1 / código 1.
5. Deixe o PWABuilder **gerar a chave de assinatura** e **baixe e guarde o keystore e as senhas** num lugar seguro (sem ele você não consegue atualizar o app).
6. Baixe o pacote: ele traz o `.aab` e o arquivo **assetlinks.json**.
7. Publique o `assetlinks.json` em `https://seudominio.com/.well-known/assetlinks.json`. Sem isso o app abre com uma barra de endereço do Chrome em cima. Se você usar o Play App Signing (recomendado), pegue também a impressão digital SHA-256 do certificado de assinatura do app no Play Console (Integridade do app) e adicione-a ao assetlinks.json.

## 3. Criar o app no Play Console
1. **Criar app** → nome DiaClaro, idioma português (Brasil), tipo App, gratuito.
2. **Ficha da loja**: use os textos do arquivo `TEXTOS-DA-LOJA.md` e os arquivos:
   - Ícone: `play-icon-512.png`
   - Gráfico de recursos: `feature-graphic-1024x500.png`
   - Capturas de tela do celular: `shot-1` a `shot-4` (1080×1920). Recomendo adicionar uma captura da aba Notícias, tirada no seu celular com notícias reais.
3. **Política de privacidade**: URL da página privacidade.html hospedada.
4. **Segurança dos dados**, **classificação de conteúdo**, **público-alvo** e **app de notícias**: respostas sugeridas em `TEXTOS-DA-LOJA.md`.
5. **Produção/Teste**: envie o `.aab`, cumpra o teste fechado se a sua conta exigir e envie para análise (costuma levar de alguns dias a uma semana).

## 4. Atualizações depois de publicado
- Mudanças no site (DiaClaro.html etc.) chegam ao app **sem nova versão na loja**: o app abre o seu site e se atualiza sozinho.
- Só precisa de nova versão na loja quando mudar o ID, o ícone, as permissões ou o pacote Android.

## 5. Observações importantes
- As notificações funcionam como no Chrome (o app Android usa o Chrome por baixo). Alertas com o app fechado dependem do Android e do Chrome e não são garantidos.
- O app depende de serviços gratuitos de terceiros (Open-Meteo, feeds de notícias e proxies). Se algum sair do ar, parte do conteúdo deixa de aparecer. Para uso comercial mais seguro, vale a pena ter um pequeno servidor próprio para as notícias.
- Os textos de notícias são de jornais de terceiros. O app mostra manchetes e leva ao site; revise as regras da Play para apps de notícias.
